package ArithmaticCalculator;

	

public class Methods {

	public int sum(int a,int b)
	{
		int c=a+b;
		return c;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
        Methods e=new Methods();
        int y=e.sum(20, 30);
        System.out.println(y);
	}

}
