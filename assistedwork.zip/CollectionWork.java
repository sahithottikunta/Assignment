package ArithmaticCalculator;
import java.util.*;
public class CollectionWork {
	public static void main(String[] args) {
		System.out.println("ArrayList");
		ArrayList<String> work=new ArrayList<String>();   
	      work.add("training");//
	      work.add("intern");    	   
	      System.out.println(work);  
		
	      System.out.println("\n");
	      System.out.println("Vector");
	      Vector<Integer> num = new Vector();
	      num.addElement(40); 
	      num.addElement(80); 
	      System.out.println(num);
	      
	      System.out.println("\n");
	      System.out.println("LinkedList");
	      LinkedList<String> var=new LinkedList<String>();  
	      var.add("Alex");  
	      var.add("John");  	      
	      Iterator<String> itr=var.iterator();  
	      while(itr.hasNext()){  
	       System.out.println(itr.next());  

}}}
