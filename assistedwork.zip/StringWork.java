package ArithmaticCalculator;

public class StringWork {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        System.out.println("Methods of Strings");
		
		String str=new String("My name is sahith");
		System.out.println(str.length());
		
		String str1=new String("Welcome");
		System.out.println(str1.substring(2));
		System.out.println("\n");
		System.out.println("Creating StringBuffer");
		StringBuffer st=new StringBuffer("Welcome to work!");
		st.append("Enjoy your day's work");
		System.out.println(st);
		System.out.println("\n");
		System.out.println("Creating StringBuilder");
		StringBuilder sb1=new StringBuilder("Happy");
		sb1.append("Learning");
		System.out.println(sb1);

		System.out.println(sb1.delete(0, 1));

		System.out.println(sb1.insert(1, "Welcome"));

		System.out.println(sb1.reverse());
	}

}
