package ArithmaticCalculator;

public class InnerClass {
	private String msg="working on java"; 
	 
	 class Inner{  
	  void hello(){System.out.println(msg+", work to do");}  
	 }  


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		InnerClass work=new InnerClass();
		InnerClass.Inner need=work.new Inner();  
		need.hello();  

	}

}
