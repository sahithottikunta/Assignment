package ArithmaticCalculator;
import java.util.*;
public class MapsWork {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<Integer,String> need=new HashMap<Integer,String>();      
	      need.put(1,"Arjun");    
	      need.put(2,"Akash");    
	      need.put(3,"Vikram");   
	       
	      System.out.println("\nThe elements of Hashmap are ");  
	      for(Map.Entry m:need.entrySet()){    
	       System.out.println(m.getKey()+" "+m.getValue());    
	      }
	      
	      TreeMap<Integer,String> work=new TreeMap<Integer,String>();    
	      work.put(4,"arun");    
	      work.put(5,"yash");    
	      work.put(6,"varun");       
	      
	      System.out.println("\nThe elements of TreeMap are ");  
	      for(Map.Entry l:work.entrySet()){    
	       System.out.println(l.getKey()+" "+l.getValue());    
	}}

}
