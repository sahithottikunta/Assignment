package ArithmaticCalculator;

public class AccessModifierPrivate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        AccessModifier g= new AccessModifier();
        g.methodDefault();
        g.methodProtected();
        g.methodPublic();
	}

}
