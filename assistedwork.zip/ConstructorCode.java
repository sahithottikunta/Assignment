package ArithmaticCalculator;
public class ConstructorCode {
	int empId;
	String empName;
	String department;
	float salary;
	//default constructor
	public ConstructorCode() {
		empId=1;
		empName="Akash";
		department="finance";
		salary=40000f;
	}
	public ConstructorCode(int empId,String empName,String department,float salary)
	{
		this.empId=empId;
		this.empName=empName;
		this.department=department;
		this.salary=salary;
	}
	public void display()
	{
		System.out.println("Id: "+empId);
		System.out.println("Name: "+empName);
		System.out.println("department: "+department);
		System.out.println("salary: "+salary);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
        ConstructorCode e=new ConstructorCode();
        ConstructorCode e1=new ConstructorCode(12,"Arjun","Training",45000);
        e.display();
        e1.display();
	}

}
