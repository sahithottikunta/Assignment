package ArithmaticCalculator;

public class ArraysWork {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]= {25,2,80,48,6,79};
		for(int i=0;i<6;i++) {
		System.out.println("Elements of array arr are: "+arr[i]);
	}
		int[][] arr1 = {
	            {22, 78, 7, 77}, 
	            {52, 56, 99} };
		System.out.println("\nLength of 1st row: " + arr1[0].length);
}}
