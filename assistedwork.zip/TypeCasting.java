package ArithmaticCalculator;

public class TypeCasting {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Implicit Type Casting");
		char req='z';
		System.out.println("Value of req: "+req);
		
		int num=req;
		System.out.println("Value of num: "+num);
		
		float val=req;
		System.out.println("Value of val: "+val);
		
		long num1=req;
		System.out.println("Value of num1: "+num1);
		
		double num2=req;
		System.out.println("Value of num2: "+num2);
		
		System.out.println("Explicit Type Casting");
		
		double dou=89.9;
		int joy=(int)dou;
		System.out.println("Value of joy is: "+joy);
	}

}
